#ifndef PROJECT_UNIT_H
#define PROJECT_UNIT_H

int read_n(char *buffer, int buf_size);
int read_size(char *buffer, unsigned int buf_size);
int read_int();
#endif //PROJECT_UNIT_H
